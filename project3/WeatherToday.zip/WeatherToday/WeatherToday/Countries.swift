//
//  Countries.swift
//  WeatherToday
//
//  Created by cscoi008 on 2019. 8. 13..
//  Copyright © 2019년 cscoi008. All rights reserved.
//

import UIKit

//countries json파일에 해당하는 class입니다.
class Countries: NSObject, Codable {
    var koreanName: String!
    var assetName: String!
}
